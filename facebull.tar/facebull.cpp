#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <set>
#include <iterator>
#include <algorithm>
#include "facebull.h"

using namespace std;

void facebull::init()
{
	ifstream infile(_filename.c_str());
	if(!infile){
		cout<<"can not open input file "<<_filename<<endl;
		exit(0);
	}
	string str;
	istringstream input_str("");
	while(getline(infile, str))
	{
		input_str.str(str);
		MachInfo info;
		string tempstr[MAC_FIELD];
		int i = 0;
		while(i < MAC_FIELD - 1)
		{
			input_str>>tempstr[i];
			tempstr[i].erase(tempstr[i].begin());
			i++;
		}
		input_str>>tempstr[MAC_FIELD-1];
		info._id = atoi(tempstr[0].c_str());
		info._c1 = atoi(tempstr[1].c_str());
		info._c2 = atoi(tempstr[2].c_str());
		info._value = atol(tempstr[3].c_str());
		_machine.push_back(info);
		_nummachine++;
		input_str.clear();
		if(info._c1 > _numnode)
		{
			_numnode = info._c1;
		}
		if(info._c2 > _numnode)
		{
			_numnode = info._c2;
		}
	}

}

void facebull::initMatrix()
{
	this->_edgeMatrix = new int* [_numnode];
	for(int i = 0; i < _numnode; i++)
	{
		_edgeMatrix[i] = new int[_numnode];
	}

	for(int i = 0; i < _numnode; i++)
		for(int j = 0; j < _numnode; j++)
			_edgeMatrix[i][j] = 0;

	this->_valueMatrix = new int* [_numnode];
	for(int i = 0; i < _numnode; i++)
	{
		_valueMatrix[i] = new int[_numnode];
	}
	for(int i = 0; i < _numnode; i++)
		for(int j = 0; j < _numnode; j++)
			_valueMatrix[i][j] = 0;

	vector<MachInfo>::iterator it1 = _machine.begin();
	vector<MachInfo>::iterator it2 = _machine.end();

	for(; it1 != it2; it1++)
	{
		int c1 = (*it1)._c1;
		int c2 = (*it1)._c2;
		unsigned long value = (*it1)._value;
		_edgeMatrix[c1 - 1][c2 - 1] = 1;
		_valueMatrix[c1 - 1][c2 - 1] = value;
	}
#ifdef DEBUG
	for(int i = 0; i < _numnode; i++)
	{
		for(int j = 0; j < _numnode; j++)
		{
			cout<<_edgeMatrix[i][j]<<" ";
		}
		cout<<endl;
	}
	cout<<endl;

	for(int i = 0; i < _numnode; i++)
	{
		for(int j = 0; j < _numnode; j++)
		{
			cout<<_valueMatrix[i][j]<<" ";
		}
		cout<<endl;
	}
	cout<<endl;
#endif
}


void facebull::getSingleRing()
{
	vector<vector<int> >::iterator it1 = _permutatevec.begin();
	vector<vector<int> >::iterator it2 = _permutatevec.end();
	for(; it1 != it2; it1++){
		bool link = true;
		unsigned long value = 0;
		for(int i = 0; i < _numnode -1; i++)
		{
			if(_edgeMatrix[(*it1)[i]][(*it1)[i+1]] <= 0){
				break;
				link = false;
			}else {
				value += _valueMatrix[(*it1)[i]][(*it1)[i+1]];
			}
		}
		if(link == false){

		}else {
			if(_edgeMatrix[(*it1)[_numnode - 1]][(*it1)[0]] <= 0){

			}else {
				value += _valueMatrix[(*it1)[_numnode - 1]][(*it1)[0]];
				if(value < _minvalue){
					_minvalue = value;
					_resultSingleRing = (*it1);
					this->_resultType = SINGLE1;
				}
			}
		}
//reverse
		for(int i = _numnode - 1; i > 0; i--)
		{
			if(_edgeMatrix[(*it1)[i]][(*it1)[i-1]] <= 0){
				break;
				link = false;
			}else {
				value += _valueMatrix[(*it1)[i]][(*it1)[i-1]];
			}
		}
			if(link == false){

			}else {
				if(_edgeMatrix[(*it1)[0]][(*it1)[_numnode - 1]] <= 0){
					link = false;
				}else {
					value += _valueMatrix[(*it1)[0]][(*it1)[_numnode - 1]];
					if(value < _minvalue){
						_minvalue = value;
						_resultSingleRing = (*it1);
						this->_resultType = SINGLE2;
					}
				}
			}
	}
}

void facebull::handleLongRing()
{
	unsigned long  maxvalue = 0;
	vector<int> maxindex;
	vector<unsigned long> pairRing;
	int breaknum = 1;
	for(int i = 0; i < _numnode; i++)
	{
		if(_edgeMatrix[i][(i + 1) % _numnode] > 0 && _edgeMatrix[(i + 1) % _numnode][i] > 0)
		{
			unsigned long pairRingvalue = _valueMatrix[i][(i + 1) % _numnode] + _valueMatrix[(i + 1) % _numnode][i];
			pairRing.push_back(pairRingvalue);
			if(pairRingvalue > maxvalue)
			{
				maxvalue = pairRingvalue;
				_maxindexpre = i + 1;
				_maxindexpost = (i + 1) % _numnode + 1;
			}
		}else {
			breaknum--;
			this->_breakindexpre = i + 1;
			this->_breakindexpost = (i + 1) % _numnode + 1;
			pairRing.push_back(MAX_VALUE);
		}
	}
	
	if(breaknum < 0)
	{
		return;
	}

	unsigned long sumlongring = 0;
	for(int i = 0; i < _numnode; i++)
	{
		if(pairRing[i] != MAX_VALUE)
		{
			sumlongring += pairRing[i];
	
		}
	}

	if(this->_breakindexpre >=0)
	{
		if(sumlongring < _minvalue)
		{
			_minvalue = sumlongring;
			_resultType = LONGBREAK;
			return;
		}
	}else {
		sumlongring -= maxvalue;
		if(sumlongring < _minvalue)
		{
			_minvalue = sumlongring;
			_resultType = LONGFULL;

			return;
		}
	}

	

}

int facebull::getonemachine(int c1, int c2)
{
	vector<MachInfo>::iterator it1 = _machine.begin();
	vector<MachInfo>::iterator it2 = _machine.end();

	for(; it1 != it2; it1++)
	{
		if((*it1)._c1 == c1 && (*it1)._c2 == c2)
			return (*it1)._id;
	}
	cerr<<"wrong in getonemachine()!"<<endl;
	return -1;
}

void facebull::selectmac()
{
	if(this->_resultType == SINGLE1)
	{
		for(int i = 0; i < _numnode - 1; i++){
			int c1 = _resultSingleRing[i] + 1;
			int c2 = _resultSingleRing[i+1] + 1;
			int id = getonemachine(c1, c2);
			_selectmachine.insert(id);
		}
		int c1 = _resultSingleRing[_numnode - 1] + 1;
		int c2 = _resultSingleRing[0] + 1;
		int id = getonemachine(c1, c2);
		_selectmachine.insert(id);
	}

	if(this->_resultType == SINGLE2)
	{
		for(int i = _numnode - 1; i > 0; i--){
			int c1 = _resultSingleRing[i] + 1;
			int c2 = _resultSingleRing[i-1] + 1;
			int id = getonemachine(c1, c2);
			_selectmachine.insert(id);
		}
		int c1 = _resultSingleRing[0] + 1;
		int c2 = _resultSingleRing[_numnode - 1] + 1;
		int id = getonemachine(c1, c2);
		_selectmachine.insert(id);
	}
	
	if(this->_resultType == LONGFULL)
	{
		vector<MachInfo>::iterator it1 = _machine.begin();
		vector<MachInfo>::iterator it2 = _machine.end();
		for(; it1 != it2; it1++)
		{
			_selectmachine.insert((*it1)._id);
		}

		int id1 = getonemachine(this->_maxindexpre, this->_maxindexpost);
		int id2 = getonemachine(this->_maxindexpost, this->_maxindexpre);
		set<int>::iterator it = _selectmachine.find(id1);
		if(it != _selectmachine.end())
			_selectmachine.erase(it);
		it = _selectmachine.find(id2);
		if(it != _selectmachine.end())
			_selectmachine.erase(it);

	}

	if(this->_resultType == LONGBREAK)
	{
		vector<MachInfo>::iterator it1 = _machine.begin();
		vector<MachInfo>::iterator it2 = _machine.end();
		for(; it1 != it2; it1++)
		{
			_selectmachine.insert((*it1)._id);
		}
		int id1 = getonemachine(this->_breakindexpre, this->_breakindexpost);
		int id2 = getonemachine(this->_breakindexpost, this->_breakindexpre);
		set<int>::iterator it = _selectmachine.find(id1);
		if(it != _selectmachine.end())
			_selectmachine.erase(it);
		it = _selectmachine.find(id2);
		if(it != _selectmachine.end())
			_selectmachine.erase(it);
		
	}

}




void facebull::output()
{
	cout<<this->_minvalue<<endl;
	ostream_iterator<int> os(cout, " ");
	copy(_selectmachine.begin(), _selectmachine.end(), os);
	cout<<endl;
}


void facebull::permute(vector<int>& vec1, int start)
{
	if(start == _numnode - 1)
	{
		_permutatevec.push_back(vec1);
	}

	for(int i = start; i < _numnode; i++)
	{
		swap(vec1[i], vec1[start]);
		permute(vec1, start + 1);
		swap(vec1[i], vec1[start]);
	}
}

void facebull::permutate()
{
	vector<int> vec1;
	for(int i = 0; i <= _numnode - 1; i++)
	{
		vec1.push_back(i);
	}
	permute(vec1, 0);
}


int main(int argc, char** argv)
{
	if(argc != 2)
	{
		cerr<<"input error"<<endl;
		exit(0);
	}
	facebull bull(argv[1]);
	bull.execute();
	return 0;
}


