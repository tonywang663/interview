#include <iostream>
#include <string>
#include <set>
#include <vector>

using namespace std;

	const unsigned long MAX_VALUE = 0xFFFFFFFF;

	const int MAC_FIELD = 4;

typedef struct{
	int _id;
	int _c1;
	int _c2;
	unsigned long _value;
} MachInfo;


class facebull{
public:
	facebull(string filename):_filename(filename),_nummachine(0), _numnode(0),_edgeMatrix(NULL),_valueMatrix(NULL),_minvalue(MAX_VALUE),_breakindexpre(-1),
		_breakindexpost(-1),_maxindexpre(-1),_maxindexpost(-1),_resultType(-1)
	{}
	~facebull(){}

	void execute()
	{
		init();
		initMatrix();
		permutate();
		getSingleRing();
		handleLongRing();
		selectmac();
		output();
	}
private:
	void init();
	void initMatrix();
	void getSingleRing();
	void handleLongRing();
	void selectmac();
	void output();
	void permutate();
	void permute(vector<int>& vec, int start);
	int getonemachine(int c1, int c2);


	string _filename;
	int _nummachine;
	int _numnode;
	
	vector<int> _pairRing1;
	vector<long> _pairRingValue;

	int ** _edgeMatrix;
	int ** _valueMatrix;

	unsigned long _minvalue;
	int _breakindexpre;
	int _breakindexpost;

	int _maxindexpre;
	int _maxindexpost;

	int _resultType;
	
	
	enum state  {SINGLE1, SINGLE2, LONGFULL, LONGBREAK};
	vector<MachInfo> _machine;
	set<int> _selectmachine;

	vector<vector<int> > _permutatevec;
	vector<int> _resultSingleRing;

};


